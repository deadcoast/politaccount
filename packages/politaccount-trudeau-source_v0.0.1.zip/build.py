# -*- coding: utf-8 -*-
"""Build politaccount-trudeau.html and trudeau.json from data_trudeau.py."""
import json, html, re, datetime, os, sys
sys.path.insert(0, os.path.dirname(__file__))
from data_trudeau import ENTRIES, SUBJECT, CABINET_DEPARTURES, PM, GOV, MIN

OUT_DIR = os.path.join(os.path.dirname(__file__), "..", "out")
os.makedirs(OUT_DIR, exist_ok=True)
GENERATED = "September 17, 2026"

# ── result vocabulary ───────────────────────────────────────────────────────
RESULT_META = {
    "VIOLATION_FOUND":          ("critical",   "Found in contravention"),
    "COURT_AGAINST_GOVERNMENT": ("critical",   "Ruled against the government"),
    "AUDIT_ADVERSE":            ("warning",    "Adverse audit"),
    "INQUIRY_FINDING":          ("warning",    "Inquiry finding"),
    "BROKEN_COMMITMENT":        ("warning",    "Commitment broken"),
    "CHARGES":                  ("proceeding", "Criminal proceeding"),
    "CHARGES_STAYED":           ("proceeding", "Charge stayed"),
    "RESIGNATION":              ("proceeding", "Resignation"),
    "CLEARED":                  ("good",       "Cleared"),
    "COURT_FOR_GOVERNMENT":     ("good",       "Ruled for the government"),
    "ADMISSION":                ("neutral",    "Admitted / reversed"),
    "UNADJUDICATED":            ("neutral",    "No adjudication"),
    "RECORD":                   ("neutral",    "On the record"),
}
CLASS_LABEL = {
    "critical": "Found against",
    "warning": "Audit, inquiry or broken commitment",
    "proceeding": "Proceeding or resignation",
    "good": "Cleared or upheld",
    "neutral": "Admitted, on the record, or unadjudicated",
}
CLASS_ORDER = ["critical", "warning", "proceeding", "neutral", "good"]
CATEGORY_LABEL = {
    "ethics": "Ethics", "conduct": "Conduct", "spending": "Spending", "procurement": "Procurement",
    "governance": "Governance", "foreign-interference": "Foreign interference", "commitments": "Commitments",
}
SUBJECT_KEY = {PM: "pm", GOV: "gov", MIN: "min"}

# ── helpers ─────────────────────────────────────────────────────────────────
MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"]
MON = [m[:3] for m in MONTHS]

def esc(s):
    return html.escape(s, quote=True) if s else ""

def parse_date(d):
    """Return (datetime.date, precision) for 'YYYY', 'YYYY-MM', 'YYYY-MM-DD'."""
    if not d: return None, None
    p = d.split("-")
    if len(p) == 1: return datetime.date(int(p[0]), 1, 1), "y"
    if len(p) == 2: return datetime.date(int(p[0]), int(p[1]), 1), "m"
    return datetime.date(int(p[0]), int(p[1]), int(p[2])), "d"

def fmt_long(d):
    dt, prec = parse_date(d)
    if not dt: return ""
    if prec == "y": return str(dt.year)
    if prec == "m": return f"{MONTHS[dt.month-1]} {dt.year}"
    return f"{MONTHS[dt.month-1]} {dt.day}, {dt.year}"

def fmt_short(d):
    dt, prec = parse_date(d)
    if not dt: return ""
    if prec == "y": return str(dt.year)
    return f"{MON[dt.month-1]} {dt.year}"

def date_range_short(a, b):
    if not b: return f"{fmt_short(a)} –"
    sa, sb = fmt_short(a), fmt_short(b)
    return sa if sa == sb else f"{sa} – {sb}"

def first_sentence(s):
    m = re.match(r"(.+?[.!?])(\s|$)", s)
    return m.group(1) if m else s

NONE_PREFIX = ("none", "no penalty", "no contravention")
def pm_html(text):
    head = first_sentence(text)
    rest = text[len(head):].strip()
    if head.lower().startswith(NONE_PREFIX):
        return f"<b>{esc(head)}</b>" + (f" {esc(rest)}" if rest else "")
    return esc(text)

def to_ordinal(dt):
    return (dt - datetime.date(2015, 1, 1)).days

# ── normalize & sort ───────────────────────────────────────────────────────
entries = []
for e in ENTRIES:
    e = dict(e)
    cls, generic = RESULT_META[e["finding"]["result"]]
    e["result_class"] = cls
    e["result_generic"] = generic
    e["subject_key"] = SUBJECT_KEY[e["subject"]]
    e["date_start_long"] = fmt_long(e["date_start"])
    e["date_end_long"] = fmt_long(e["date_end"]) if e.get("date_end") else None
    e["date_range_short"] = date_range_short(e["date_start"], e.get("date_end"))
    e["pm_short"] = first_sentence(e["consequence_pm"])
    e.setdefault("secondary", [])
    entries.append(e)

entries.sort(key=lambda e: (parse_date(e["date_start"])[0], e["title"]))
for i, e in enumerate(entries, 1):
    e["no"] = i

# ── stats ───────────────────────────────────────────────────────────────────
def count(pred): return sum(1 for e in entries if pred(e))
term_start = datetime.date.fromisoformat(SUBJECT["term_start"])
term_end = datetime.date.fromisoformat(SUBJECT["term_end"])
days_in_office = (term_end - term_start).days
stats = {
    "entries": len(entries),
    "by_subject": {k: count(lambda e, k=k: e["subject"] == k) for k in (PM, GOV, MIN)},
    "pm_contraventions": count(lambda e: e["subject"] == PM and e["finding"]["result"] == "VIOLATION_FOUND"),
    "minister_contraventions": count(lambda e: e["subject"] == MIN and e["finding"]["result"] == "VIOLATION_FOUND"),
    "court_against": count(lambda e: e["finding"]["result"] == "COURT_AGAINST_GOVERNMENT"),
    "audits": count(lambda e: e["finding"]["result"] == "AUDIT_ADVERSE"),
    "inquiries": count(lambda e: e["finding"]["result"] == "INQUIRY_FINDING"),
    "cleared_or_upheld": count(lambda e: e["finding"]["result"] in ("CLEARED", "COURT_FOR_GOVERNMENT")),
    "unadjudicated": count(lambda e: e["finding"]["result"] == "UNADJUDICATED"),
    "cabinet_departures": len(CABINET_DEPARTURES),
    "penalties_on_pm": 0,
    "total_penalties_dollars": 200,
    "days_in_office": days_in_office,
    "by_class": {c: count(lambda e, c=c: e["result_class"] == c) for c in CLASS_ORDER},
}
minister_names = sorted({e["actors"][0] for e in entries if e["subject"] == MIN and e["finding"]["result"] == "VIOLATION_FOUND"})
audit_titles = [e["title"] for e in entries if e["finding"]["result"] == "AUDIT_ADVERSE"]
cleared_titles = [e["title"] for e in entries if e["finding"]["result"] in ("CLEARED", "COURT_FOR_GOVERNMENT")]

# ── JSON ────────────────────────────────────────────────────────────────────
dataset = {
    "platform": "politaccount",
    "subject": SUBJECT,
    "generated": "2026-09-17",
    "record_current_as_of": "2026-09-17",
    "result_vocabulary": {k: {"class": v[0], "label": v[1]} for k, v in RESULT_META.items()},
    "stats": stats,
    "cabinet_departures": CABINET_DEPARTURES,
    "entries": entries,
}
with open(os.path.join(OUT_DIR, "trudeau.json"), "w", encoding="utf-8") as f:
    json.dump(dataset, f, ensure_ascii=False, indent=2)

# ── HTML pieces ─────────────────────────────────────────────────────────────
def tag_html(e, small=False):
    return (f'<span class="tag tag-{e["result_class"]}{" tag-sm" if small else ""}">'
            f'<i class="dot" aria-hidden="true"></i>{esc(e["finding"]["label"])}</span>')

def entry_html(e):
    f = e["finding"]
    body_line = esc(f["body"])
    if f.get("date"): body_line += f' <span class="fdate">· {esc(fmt_long(f["date"]))}</span>'
    secondary = "".join(f'<span class="chip">{esc(s)}</span>' for s in e["secondary"])
    srcs = []
    for s in e["sources"]:
        meta = esc(s["publisher"])
        if s.get("date"): meta += f" · {esc(fmt_long(s['date']))}"
        prim = '<span class="prim">Primary</span>' if s.get("primary") else ""
        srcs.append(f'<li><a href="{esc(s["url"])}" target="_blank" rel="noopener">{esc(s["title"])}</a>'
                    f'<span class="src-meta">{meta}{prim}</span></li>')
    cost = f'<dt>Public cost</dt><dd>{esc(e["public_cost"])}</dd>' if e.get("public_cost") else ""
    actors = ", ".join(esc(a) for a in e["actors"])
    dates = esc(e["date_start_long"]) + (f' → {esc(e["date_end_long"])}' if e["date_end_long"] else " → open")
    return f'''
<article class="entry" id="e-{e["id"]}" data-id="{e["id"]}" data-no="{e["no"]}" data-subject="{e["subject_key"]}" data-class="{e["result_class"]}" data-cat="{e["category"]}" data-date="{to_ordinal(parse_date(e["date_start"])[0])}">
  <button class="entry-head" type="button" aria-expanded="false" aria-controls="b-{e["id"]}" id="h-{e["id"]}">
    <span class="idx"><span class="no">No. {e["no"]:02d}</span>
    <span class="dates">{esc(e["date_range_short"])}</span></span>
    <span class="ttl"><span class="title">{esc(e["title"])}</span><span class="pmline"><b>PM</b> {esc(e["pm_short"])}</span></span>
    {tag_html(e)}
    <span class="chev" aria-hidden="true"></span>
  </button>
  <div class="entry-body" id="b-{e["id"]}" hidden>
    <div class="col-main">
      <div class="meta-row"><span class="k">Subject</span> {esc(e["subject"])} <span class="sep">·</span> <span class="k">Category</span> {esc(CATEGORY_LABEL[e["category"]])} <span class="sep">·</span> <span class="k">Dates</span> {dates}</div>
      <p class="summary">{esc(e["summary"])}</p>
      <div class="finding finding-{e["result_class"]}">
        <div class="k">Finding <span class="fbody">— {body_line}</span></div>
        <blockquote class="quote">{esc(f["quote"])}</blockquote>
        {("<div class='chips'>" + secondary + "</div>") if secondary else ""}
      </div>
      <div class="actors"><span class="k">Named</span> {actors}</div>
    </div>
    <div class="col-side">
      <dl class="cons">
        <dt>To the Prime Minister</dt><dd>{pm_html(e["consequence_pm"])}</dd>
        <dt>To others</dt><dd>{esc(e["consequence_others"])}</dd>
        {cost}
        <dt>Status · September 2026</dt><dd>{esc(e["status"])}</dd>
      </dl>
      <div class="sources"><div class="k">Sources</div><ol>{"".join(srcs)}</ol></div>
    </div>
  </div>
</article>'''

def table_row(e):
    return (f'<tr><td class="mono">{e["no"]:02d}</td>'
            f'<td><a href="#e-{e["id"]}" class="tlink" data-id="{e["id"]}">{esc(e["title"])}</a>'
            f'<div class="tdate mono">{esc(e["date_range_short"])}</div></td>'
            f'<td>{tag_html(e, True)}</td>'
            f'<td>{pm_html(e["consequence_pm"])}</td>'
            f'<td>{esc(e["consequence_others"])}</td></tr>')

# ── timeline SVG ────────────────────────────────────────────────────────────
T0 = datetime.date(2015, 7, 1); T1 = datetime.date(2025, 7, 1)
W, H = 1000, 236
LX, RX = 150, 992
LANES = [(PM, 52), (GOV, 122), (MIN, 192)]
def xpos(dt):
    return LX + (RX - LX) * (dt - T0).days / (T1 - T0).days

def mark(e, cx, cy):
    cls = e["result_class"]; c = f"var(--c-{cls})"
    title = f'<title>No. {e["no"]:02d} · {esc(e["title"])} — {esc(e["finding"]["label"])}</title>'
    common = f'class="mk mk-{cls}" data-id="{e["id"]}" tabindex="0" role="button" aria-label="No. {e["no"]}: {esc(e["title"])}"'
    if cls == "critical":
        return f'<rect {common} x="{cx-5.5:.1f}" y="{cy-5.5:.1f}" width="11" height="11" fill="{c}" stroke="var(--surface)" stroke-width="2">{title}</rect>'
    if cls == "warning":
        return f'<rect {common} x="{cx-5:.1f}" y="{cy-5:.1f}" width="10" height="10" transform="rotate(45 {cx:.1f} {cy:.1f})" fill="{c}" stroke="var(--surface)" stroke-width="2">{title}</rect>'
    if cls == "good":
        return f'<polygon {common} points="{cx:.1f},{cy-6.5:.1f} {cx+6:.1f},{cy+4.5:.1f} {cx-6:.1f},{cy+4.5:.1f}" fill="{c}" stroke="var(--surface)" stroke-width="2">{title}</polygon>'
    if cls == "neutral":
        return f'<circle {common} cx="{cx:.1f}" cy="{cy:.1f}" r="4.5" fill="var(--surface)" stroke="{c}" stroke-width="2">{title}</circle>'
    return f'<circle {common} cx="{cx:.1f}" cy="{cy:.1f}" r="5.5" fill="{c}" stroke="var(--surface)" stroke-width="2">{title}</circle>'

def timeline_svg():
    parts = [f'<svg class="tl" viewBox="0 0 {W} {H}" width="100%" role="img" aria-label="Timeline of the 59 entries, 2015 to 2025, in three lanes: Prime Minister, Government, Ministers and caucus">']
    # year grid
    for y in range(2016, 2026):
        x = xpos(datetime.date(y, 1, 1))
        parts.append(f'<line x1="{x:.1f}" y1="22" x2="{x:.1f}" y2="{H-24}" class="grid"/>')
        parts.append(f'<text x="{x:.1f}" y="{H-8}" class="tick" text-anchor="middle">{y}</text>')
    # term bounds
    for d, lab, anchor in ((term_start, "Sworn in", "start"), (term_end, "Left office", "end")):
        x = xpos(d)
        parts.append(f'<line x1="{x:.1f}" y1="14" x2="{x:.1f}" y2="{H-24}" class="bound"/>')
        parts.append(f'<text x="{x + (4 if anchor=="start" else -4):.1f}" y="12" class="tick" text-anchor="{anchor}">{lab} · {fmt_short(d.isoformat())}</text>')
    # lanes
    for name, cy in LANES:
        parts.append(f'<line x1="{LX}" y1="{cy}" x2="{RX}" y2="{cy}" class="lane"/>')
        parts.append(f'<text x="{LX-10}" y="{cy+4}" class="lane-label" text-anchor="end">{esc(name)}</text>')
    # marks, with simple horizontal de-collision per lane
    lane_y = {n: y for n, y in LANES}
    placed = {n: [] for n, _ in LANES}
    for e in entries:
        dt, _ = parse_date(e["date_start"])
        cx = xpos(dt); cy = lane_y[e["subject"]]
        # stack vertically if too close to a previous mark in the same lane
        offset = 0
        for (px, po) in placed[e["subject"]]:
            if abs(px - cx) < 12 and po == offset:
                offset = offset + 1
        dy = [0, -14, 14, -28, 28][min(offset, 4)]
        placed[e["subject"]].append((cx, offset))
        parts.append(mark(e, cx, cy + dy))
    parts.append('</svg>')
    return "".join(parts)

# ── assemble page ───────────────────────────────────────────────────────────
ledger = "".join(entry_html(e) for e in entries)
table = "".join(table_row(e) for e in entries)
elections = " · ".join(f'{x["year"]} {x["result"].lower()} ({x["seats"]})' for x in SUBJECT["elections"])
departures = "".join(f'<li><span class="mono">{esc(fmt_long(d["date"]))}</span> {esc(d["name"])} — {esc(d["how"])}</li>' for d in CABINET_DEPARTURES)

page = open(os.path.join(os.path.dirname(__file__), "template.html"), encoding="utf-8").read()
repl = {
    "{{GENERATED}}": GENERATED,
    "{{N}}": str(stats["entries"]),
    "{{N_PM}}": str(stats["by_subject"][PM]),
    "{{N_GOV}}": str(stats["by_subject"][GOV]),
    "{{N_MIN}}": str(stats["by_subject"][MIN]),
    "{{DAYS}}": f"{days_in_office:,}",
    "{{ELECTIONS}}": elections,
    "{{PM_CONTRAVENTIONS}}": str(stats["pm_contraventions"]),
    "{{MIN_CONTRAVENTIONS}}": str(stats["minister_contraventions"]),
    "{{MIN_NAMES}}": esc(", ".join(minister_names)),
    "{{COURT_AGAINST}}": str(stats["court_against"]),
    "{{AUDITS}}": str(stats["audits"]),
    "{{AUDIT_LIST}}": esc("; ".join(audit_titles)),
    "{{INQUIRIES}}": str(stats["inquiries"]),
    "{{CLEARED}}": str(stats["cleared_or_upheld"]),
    "{{CLEARED_LIST}}": esc("; ".join(cleared_titles)),
    "{{DEPARTURES}}": str(stats["cabinet_departures"]),
    "{{DEPARTURE_LIST}}": departures,
    "{{UNADJ}}": str(stats["unadjudicated"]),
    "{{TIMELINE}}": timeline_svg(),
    "{{LEDGER}}": ledger,
    "{{TABLE}}": table,
    "{{N_CRIT}}": str(stats["by_class"]["critical"]),
    "{{N_WARN}}": str(stats["by_class"]["warning"]),
    "{{N_PROC}}": str(stats["by_class"]["proceeding"]),
    "{{N_GOOD}}": str(stats["by_class"]["good"]),
    "{{N_NEUT}}": str(stats["by_class"]["neutral"]),
}
for k, v in repl.items():
    page = page.replace(k, v)
assert "{{" not in page, re.findall(r"\{\{[A-Z_]+\}\}", page)[:5]
with open(os.path.join(OUT_DIR, "politaccount-trudeau.html"), "w", encoding="utf-8") as f:
    f.write(page)
print(f"entries={stats['entries']} days={days_in_office} stats={json.dumps(stats['by_class'])} html={len(page)/1024:.0f}KB")

# -*- coding: utf-8 -*-
"""
Politaccount scales — two rating scales for leaders of first-world democracies.

  OA   Operational Accountability   how they operated; how they were held to account, if at all;
                                    whether it showed in what they did next.
  POC  Provable Observable Corruption
                                    corrupt acts on the public record, scored by the common meaning of
                                    the word and by the strength of the evidence — not by whether the
                                    act was illegal where and when it happened.

Both scales are computed from the same case data every leader gets (trudeau.json) plus one code file per
leader (codes_<leader>.py). Every rule, weight and threshold lives here, fixed before any second leader is
scored. Nothing in this file refers to a party or a policy.
"""
import json, os, sys, datetime

# ────────────────────────────────────────────────────────────────────────────────────────────────────
# SHARED — case weight (severity), computed from the record, not chosen
# ────────────────────────────────────────────────────────────────────────────────────────────────────
# S = 1 + [harm or money] + [a body found against them], capped at 3.
#   harm   direct harm to identifiable people or to a democratic process, on the record (coded, with the fact)
#   money  ≥ $10 million of public money spent, or in play (cost_cad or a documented programme value)
#   against a finding against the leader, the government or a minister by a court, an officer of Parliament,
#          an auditor, a public inquiry, a committee report, or the record itself (a written commitment not met)
MONEY_THRESHOLD = 10_000_000
AGAINST_BY_RESULT = {"VIOLATION_FOUND", "COURT_AGAINST_GOVERNMENT", "AUDIT_ADVERSE", "BROKEN_COMMITMENT"}

# ────────────────────────────────────────────────────────────────────────────────────────────────────
# OA — three pillars, each scored 0–4 per case
# ────────────────────────────────────────────────────────────────────────────────────────────────────
OA_PILLARS = {
 "operate": ("Operate", "How they ran it, before anyone ruled on it.", {
    4: "Within the rules. The case exists because an accusation was examined and found clean, or because a lawful, disclosed act was put on the record.",
    3: "Within the rules on the whole; a lapse in judgment or process, no rule broken.",
    2: "Rules bent, process skipped, or warnings unheeded; no finding of rule-breaking, but the deciding body criticized the conduct, or the government admitted it.",
    1: "Rules broken by the government or a minister; a written commitment abandoned; an audit found money wasted or rules ignored.",
    0: "Rules broken by the leader personally; a court found the government acted outside the law; or people were harmed by the rule-breaking."}),
 "answer": ("Answer", "How they were held to account, if at all.", {
    4: "Cooperated fully, accepted the finding, and a real consequence landed at the top: resignation, removal, restitution, a reversal at cost.",
    3: "Cooperated and accepted the finding; the consequence fell on someone else, or was partial: a minister out, a reversal, an apology with a change.",
    2: "Accepted the finding in words; no consequence at the top; or an apology and nothing else.",
    1: "Disputed or deflected the finding: denied, minimized, blamed others, changed the subject; no consequence.",
    0: "Obstructed: withheld records from an investigator or Parliament, used cabinet confidence to block investigators, ended the process (prorogation, a confidence vote), or went to court to keep evidence hidden."}),
 "show": ("Show", "Whether it showed in what they did next.", {
    4: "The rule was changed or the practice ended, and nothing of the kind recurred in the record.",
    3: "A concrete corrective step on the record (a law, a process, money delivered, a replacement built); no repeat.",
    2: "No repeat on the record; nothing changed either.",
    1: "A corrective step promised and not delivered, or a related conduct recurred in a lesser form.",
    0: "The same conduct recurred after the finding — a second breach of the same law, a second missed written target, a second refusal of the same order."}),
}
OA_BANDS = [  # lower bound, name, one line
 (80, "Accountable",   "Answered, bore consequences, changed."),
 (60, "Answerable",    "Answered; consequences rare; some change."),
 (40, "Deflecting",    "Findings accepted in words; nothing borne; little change."),
 (20, "Evasive",       "Findings disputed; obstruction at times; conduct repeated."),
 (0,  "Unaccountable", "Obstruction as the norm; no consequences; the same conduct again and again."),
]

# ────────────────────────────────────────────────────────────────────────────────────────────────────
# POC — corrupt-act types, defined by observable elements (an elements test, in plain words)
# ────────────────────────────────────────────────────────────────────────────────────────────────────
# A case scores only if EVERY element of the type is on the record at evidence grade E2 or better.
# The case's grade is the LOWEST grade among its elements. Legality is not an element.
POC_TYPES = {
 "T1": ("Self-dealing and conflicts", 3.0, [
        "a benefit — a gift, money, travel, a contract, a licence, a programme — to the office-holder, their family, their party, or a close associate",
        "the giver or recipient had, or sought, business with the government",
        "the office-holder did not refuse it, or did not recuse from the decision"]),
 "T2": ("Interference with an independent process", 4.0, [
        "the office-holder or their office intervened in, pressured, or publicly pre-judged",
        "a decision reserved to an independent actor: a prosecutor, a judge, the police, an officer of Parliament, an arm's-length appointment",
        "without lawful authority to direct that decision"]),
 "T3": ("Abuse of state power against people", 4.0, [
        "state power was used against people: detention, property, bank accounts, prosecution, surveillance",
        "a court found the legal conditions for using it were not met, or that it breached their rights"]),
 "T4": ("Public money to insiders, or without the rules", 3.0, [
        "public funds, contracts, grants or appointments went",
        "to insiders, friends, party-connected people, ineligible recipients, or without the controls the rules require",
        "as found by an auditor, an officer of Parliament, a court, a recorded vote of Parliament, or admitted — beyond ordinary error"]),
 "T5": ("False statements to the public", 2.0, [
        "a public statement of fact by the office-holder, their office, or a minister",
        "contradicted by a document, a finding, or their own later statement on the record",
        "about a matter they were in a position to know"]),
 "T6": ("Obstruction of scrutiny", 3.0, [
        "an investigator, a committee, a court, an inquiry, or Parliament sought records or answers",
        "the office-holder or government withheld them, redacted beyond the order, ended the process (prorogation, a confidence vote, dissolution), or went to court against disclosure",
        "as shown by an order, a ruling, a formal admonishment, or the record"]),
 "T7": ("Breach of their own written standard", 1.5, [
        "a written standard the office-holder set, signed, or swore to",
        "was broken, per a finding or an admission",
        "with none of the types above present"]),
}
EVIDENCE = {  # grade: (name, multiplier, meaning)
 "E4": ("Adjudicated", 1.0, "A court, an officer of Parliament, an auditor, or a public inquiry found it."),
 "E3": ("Admitted / own record", 1.0, "They admitted it, or it is their own act or document on the record: a settlement paid, a lawsuit filed, an itinerary issued, a statement made."),
 "E2": ("Documented, no ruling", 0.6, "On the public record — sworn testimony, released documents, a recorded vote of the House — but no body with authority ruled on it."),
 "E1": ("Reported, never examined", 0.0, "Reported by major outlets, denied or unanswered, examined by nobody. Listed. Scores nothing."),
}
PROXIMITY = {  # who did it: (name, multiplier)
 "him":        ("The leader personally: his own act or statement, or a decision he announced and defended as his own", 1.0),
 "office":     ("His staff, or a cabinet decision carried by a minister", 0.8),
 "minister":   ("A minister or MP, personally", 0.5),
 "government": ("A department, agency or body under the government", 0.4),
}
SECONDARY_WEIGHT = 0.5     # a second or third type on the same case, with its own distinct elements met
MAX_SECONDARY = 2
LEADER_MAJOR_ACT = 12.0    # the unit the bands are expressed in: B4 × E1.0 × him × S3

# POC bands are structural — each is a checkable fact about the ledger, not a threshold alone.
POC_BANDS = [
 ("None",     "No proven corrupt act on the record."),
 ("Isolated", "Proven acts, none by the leader personally."),
 ("Repeated", "More than one proven act by the leader personally, or one by the leader and three or more across the government."),
 ("Pattern",  "Proven acts by the leader personally in three or more types, or the same type again after an adverse finding."),
 ("Systemic", "A pattern, plus obstruction of scrutiny and false statements to the public both proven, plus a repeat after an adverse finding."),
]

# ────────────────────────────────────────────────────────────────────────────────────────────────────
# engine
# ────────────────────────────────────────────────────────────────────────────────────────────────────
def severity(e, code):
    harm = bool(code.get("harm"))
    money = (e.get("cost_cad") or 0) >= MONEY_THRESHOLD or (code.get("money_in_play") or 0) >= MONEY_THRESHOLD
    against = e["finding"]["result"] in AGAINST_BY_RESULT or bool(code.get("against"))
    s = 1 + (1 if (harm or money) else 0) + (1 if against else 0)
    return min(3, s), {"harm": harm, "money": money, "against": against}

def poc_points(code, S):
    """Returns (points, rows) — one row per scored type on the case."""
    rows = []
    types = code.get("poc") or []
    for i, t in enumerate(types):
        base = POC_TYPES[t["type"]][1]
        emul = EVIDENCE[t["evidence"]][1]
        pmul = PROXIMITY[t["who"]][1]
        w = 1.0 if i == 0 else SECONDARY_WEIGHT
        pts = base * emul * pmul * S * w if t["evidence"] != "E1" else 0.0
        rows.append({"type": t["type"], "type_name": POC_TYPES[t["type"]][0], "evidence": t["evidence"], "who": t["who"],
                     "role": "primary" if i == 0 else "secondary", "base": base, "e_mult": emul, "p_mult": pmul, "weight": w,
                     "points": round(pts, 2), "elements": t.get("elements", ""), "cleared_under_law": bool(t.get("cleared_under_law")), "note": t.get("note", "")})
    assert len(types) <= 1 + MAX_SECONDARY
    return round(sum(r["points"] for r in rows), 2), rows

def oa_case(code):
    ps = {k: code.get(k) for k in ("operate", "answer", "show")}
    avail = [v for v in ps.values() if v is not None]
    if not avail: return None, ps
    return sum(avail) / (4.0 * len(avail)), ps

def band_oa(score):
    for lo, name, line in OA_BANDS:
        if score >= lo: return name, line
    return OA_BANDS[-1][1], OA_BANDS[-1][2]

def band_poc(ledger):
    """Structural band. Only adjudicated or admitted acts (E4, E3) count toward the band tests;
    documented-but-unruled acts (E2) score points but never move the band."""
    scored = [r for r in ledger if r["points"] > 0 and r["evidence"] in ("E4", "E3")]
    if not scored: return "None", POC_BANDS[0][1], {}
    leader_types = {r["type"] for r in scored if r["who"] == "him"}
    leader_cases = {r["case"] for r in scored if r["who"] == "him"}
    all_cases = {r["case"] for r in scored}
    obstruction = any(r["type"] == "T6" for r in scored)
    deception = any(r["type"] == "T5" for r in scored)
    repeat = any(r.get("repeat_after_finding") for r in scored)
    facts = {"leader_cases": len(leader_cases), "leader_types": sorted(leader_types), "cases": len(all_cases),
             "obstruction_proven": obstruction, "false_statements_proven": deception, "repeat_after_adverse_finding": repeat}
    if len(leader_cases) == 0: return "Isolated", POC_BANDS[1][1], facts
    pattern = len(leader_types) >= 3 or repeat
    if pattern and obstruction and deception and repeat: return "Systemic", POC_BANDS[4][1], facts
    if pattern: return "Pattern", POC_BANDS[3][1], facts
    if len(leader_cases) >= 2 or len(all_cases) >= 4: return "Repeated", POC_BANDS[2][1], facts
    return "Isolated", POC_BANDS[1][1], facts

def compute(dataset, codes):
    entries = dataset["entries"]; by_id = {e["id"]: e for e in entries}
    missing = [e["id"] for e in entries if e["id"] not in codes]; extra = [k for k in codes if k not in by_id]
    assert not missing and not extra, (missing, extra)
    term = dataset["subject"]
    years = (datetime.date.fromisoformat(term["term_end"]) - datetime.date.fromisoformat(term["term_start"])).days / 365.25

    cases = []; ledger = []; listed = []
    for e in entries:
        c = codes[e["id"]]
        S, sfacts = severity(e, c)
        oa, pillars = oa_case(c)
        pts, rows = poc_points(c, S)
        for r in rows:
            r.update({"case": e["id"], "headline": e["plain"]["headline"], "years": e["years"], "who_case": e["who"], "S": S,
                      "repeat_after_finding": bool(c.get("repeat_after_finding")) if r["role"] == "primary" else False})
            (ledger if r["evidence"] != "E1" else listed).append(r)
        cases.append({"id": e["id"], "no": e["no"], "headline": e["plain"]["headline"], "who": e["who"], "subject_key": e["subject_key"], "years": e["years"],
                      "label": e["plain"]["label"], "result": e["finding"]["result"], "result_class": e["result_class"], "S": S, "S_facts": sfacts,
                      "oa": None if oa is None else round(oa * 100, 1), "pillars": pillars, "oa_notes": c.get("oa_notes", {}),
                      "repeat_of": c.get("repeat_of"), "poc_points": pts, "poc_rows": rows, "poc_note": c.get("poc_note", "")})

    # OA aggregate
    def agg(sel):
        num = sum(x["S"] * x["oa"] / 100 for x in sel if x["oa"] is not None); den = sum(x["S"] for x in sel if x["oa"] is not None)
        return round(100 * num / den, 1) if den else None
    def pillar_agg(sel, k):
        num = sum(x["S"] * x["pillars"][k] for x in sel if x["pillars"][k] is not None); den = sum(4 * x["S"] for x in sel if x["pillars"][k] is not None)
        return round(100 * num / den, 1) if den else None
    oa_score = agg(cases)
    oa = {"score": oa_score, "band": band_oa(oa_score)[0], "band_line": band_oa(oa_score)[1],
          "pillars": {k: {"name": OA_PILLARS[k][0], "score": pillar_agg(cases, k), "cases": sum(1 for x in cases if x["pillars"][k] is not None)} for k in OA_PILLARS},
          "by_who": {w: agg([x for x in cases if x["subject_key"] == w]) for w in ("pm", "gov", "min")},
          "cases_scored": sum(1 for x in cases if x["oa"] is not None),
          "obstructed": sorted(x["id"] for x in cases if x["pillars"]["answer"] == 0),
          "no_consequence": sum(1 for x in cases if x["pillars"]["answer"] is not None and x["pillars"]["answer"] <= 2),
          "repeats": sorted(x["id"] for x in cases if x["pillars"]["show"] == 0),
          "distribution": {k: {str(v): sum(1 for x in cases if x["pillars"][k] == v) for v in range(5)} for k in OA_PILLARS}}

    # POC aggregate
    total = round(sum(r["points"] for r in ledger), 1)
    band, band_line, facts = band_poc(ledger)
    by_type = {t: round(sum(r["points"] for r in ledger if r["type"] == t), 1) for t in POC_TYPES}
    by_who = {w: round(sum(r["points"] for r in ledger if r["who"] == w), 1) for w in PROXIMITY}
    by_ev = {g: sum(1 for r in ledger if r["evidence"] == g) for g in ("E4", "E3", "E2")}
    poc = {"points": total, "per_year": round(total / years, 1), "leader_major_acts": round(total / LEADER_MAJOR_ACT, 1),
           "band": band, "band_line": band_line, "band_facts": facts,
           "scored_acts": len(ledger), "scored_cases": len({r["case"] for r in ledger}), "listed_unexamined": len(listed),
           "cleared_under_law": sorted({r["case"] for r in ledger if r["cleared_under_law"]}),
           "by_type": by_type, "by_who": by_who, "by_evidence": by_ev,
           "ledger": sorted(ledger, key=lambda r: -r["points"]), "listed": listed}

    return {"scales_version": "1.0.0", "computed": datetime.date.today().isoformat(), "subject": term, "years_in_office": round(years, 2),
            "oa": oa, "poc": poc, "cases": cases,
            "definitions": {"oa_pillars": {k: {"name": v[0], "line": v[1], "rubric": {str(s): t for s, t in v[2].items()}} for k, v in OA_PILLARS.items()},
                            "oa_bands": [{"min": lo, "name": n, "line": l} for lo, n, l in OA_BANDS],
                            "poc_types": {k: {"name": v[0], "base": v[1], "elements": v[2]} for k, v in POC_TYPES.items()},
                            "evidence": {k: {"name": v[0], "multiplier": v[1], "meaning": v[2]} for k, v in EVIDENCE.items()},
                            "proximity": {k: {"name": v[0], "multiplier": v[1]} for k, v in PROXIMITY.items()},
                            "severity": {"rule": "S = 1 + [harm or ≥$10M public money] + [a body found against them], capped at 3", "money_threshold": MONEY_THRESHOLD},
                            "secondary_weight": SECONDARY_WEIGHT, "leader_major_act_points": LEADER_MAJOR_ACT,
                            "poc_bands": [{"name": n, "test": t} for n, t in POC_BANDS]}}

if __name__ == "__main__":
    here = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, here)
    from codes_trudeau import CODES
    d = json.load(open(os.path.join(here, "..", "out", "trudeau.json"), encoding="utf-8"))
    r = compute(d, CODES)
    out = os.path.join(here, "..", "out", "scales_trudeau.json")
    json.dump(r, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    oa, poc = r["oa"], r["poc"]
    print(f"OA  {oa['score']}  {oa['band']}   operate={oa['pillars']['operate']['score']} answer={oa['pillars']['answer']['score']} show={oa['pillars']['show']['score']}  "
          f"by who: pm={oa['by_who']['pm']} gov={oa['by_who']['gov']} min={oa['by_who']['min']}  obstructed={len(oa['obstructed'])} repeats={len(oa['repeats'])}")
    print(f"POC {poc['points']} pts  {poc['band']}   acts={poc['scored_acts']} cases={poc['scored_cases']} listed={poc['listed_unexamined']} "
          f"per_year={poc['per_year']} LMA={poc['leader_major_acts']}  by_type={poc['by_type']}  by_who={poc['by_who']}  ev={poc['by_evidence']}")
    print("facts:", poc["band_facts"])
    for row in poc["ledger"]:
        print(f"  {row['points']:>5}  {row['type']} {row['evidence']} {row['who']:<10} S{row['S']} {row['role'][:3]}  {row['case']}")

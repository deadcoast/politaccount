# -*- coding: utf-8 -*-
"""
Codes for Record 001 (Justin Trudeau) against the two scales in scales.py.

One entry per case in trudeau.json. Every number here must be defensible from that case's own finding,
quote, consequence lines and sources — the notes say which fact carries each code.

  operate / answer / show   OA pillar scores, 0–4 per the rubric in scales.py; None = not applicable
  harm                      direct harm to identifiable people or a democratic process, on the record
  money_in_play             public money at stake where cost_cad is absent (documented programme value)
  against                   a finding against them by a body not already covered by the result type
  repeat_of                 later case(s) in which the same conduct recurred — the basis for show=0/1
  poc                       list of corrupt-act types whose elements are all on the record; first = primary
                            evidence E1 = listed, scores nothing
"""

def T(type, evidence, who, elements, note="", cleared_under_law=False):
    return dict(type=type, evidence=evidence, who=who, elements=elements, note=note, cleared_under_law=cleared_under_law)

CODES = {

# ── 2015 ──
"boil-water-advisories-promise": dict(
    operate=1, answer=2, show=2, harm=True,
    oa_notes=dict(operate="A written commitment abandoned; the Auditor General: the department 'did not meet its commitment'.",
                  answer="The minister accepted the report and said the commitment 'remains firm'. No new date. No consequence.",
                  show="More money pledged; the funding formula the AG flagged was unchanged; no new deadline. No later repeat in the record."),
    poc=[], poc_note="A missed commitment. No private benefit, no false statement, no rule broken: not corruption."),

"fiscal-record-2015-promise": dict(
    operate=1, answer=1, show=0, repeat_of=["freeland-resignation"],
    oa_notes=dict(operate="Two written targets (deficits under $10 billion, balance in 2019). Neither met.",
                  answer="The target was replaced with a 'debt-to-GDP anchor' rather than acknowledged as missed.",
                  show="A second written ceiling, $40.1 billion for 2023–24, came in at $61.9 billion."),
    poc=[], poc_note="A fiscal outcome. Not corruption unless the promise was made knowing it would not be kept; the record does not show that."),

"electoral-reform": dict(
    operate=1, answer=1, show=0, repeat_of=["fiscal-record-2015-promise", "boil-water-advisories-promise"],
    oa_notes=dict(operate="A platform commitment cancelled by his own mandate letter.",
                  answer="Deflected onto the absence of consensus; no acknowledgment of the promise itself until the 2025 resignation speech.",
                  show="Two more written commitments were missed after this one: the balanced budget, the water advisories."),
    poc=[], poc_note="A broken promise, not a false statement of fact. Not corruption."),

# ── 2016 ──
"phoenix-pay-system": dict(
    operate=1, answer=2, show=2, harm=True,
    oa_notes=dict(operate="'An incomprehensible failure of project management and oversight.' Switched on despite the state it was in.",
                  answer="The reports were accepted. No minister or deputy minister was removed.",
                  show="A replacement is being built at $4.2 billion; Phoenix is still running with 233,000 unresolved transactions."),
    poc=[], poc_note="Mismanagement on a vast scale. No insider benefit, no rule-breaking for gain: not corruption. Scored in OA."),

"elbowgate": dict(
    operate=3, answer=3, show=2,
    oa_notes=dict(operate="Physical contact with two MPs on the floor of the House. A lapse, no rule of office broken.",
                  answer="Two apologies, referred to committee, accepted.", show="Nothing of the kind recurred."),
    poc=[], poc_note="Personal conduct. Not corruption."),

"cash-for-access-fundraisers": dict(
    operate=2, answer=3, show=4,
    oa_notes=dict(operate="The commissioner: 'not very savoury'. No breach of the Act as written.",
                  answer="Answered the commissioner's questions; ended the private-home format in January 2017.",
                  show="Bill C-50 required notice and reporting of leaders' fundraisers. No repeat in the record."),
    poc=[T("T7", "E3", "him",
           "His own Open and Accountable Government (2015), Annex B: 'no preferential access to government, or appearance of preferential access ... because they have made financial contributions'. Face time sold at $1,525 in private homes is the appearance the standard names. Admitted by ending the format.",
           note="Cleared under the Conflict of Interest Act; scored under his own written standard, which is broader.", cleared_under_law=True)],
    poc_note="Element (b) of self-dealing — that the guests had business before the government — is not on this record for each guest, so the case scores as a breach of his own standard, not as self-dealing."),

"tootoo-resignation": dict(
    operate=3, answer=3, show=None,
    oa_notes=dict(operate="A minister's personal conduct.", answer="He left cabinet and caucus the same day.", show="Individual conduct; not applicable."),
    poc=[], poc_note="Personal conduct. Not corruption."),

"trudeau-foundation-donation": dict(
    operate=3, answer=2, show=None,
    oa_notes=dict(operate="He had withdrawn from the foundation in 2014; the intercepts concern the foundation and the donors.",
                  answer="Said he had no involvement. The Auditor General declined; no body examined it.", show="Not applicable."),
    poc=[T("T1", "E1", "him", "If proven: a benefit to a family foundation, directed by a foreign state. His own role is not on the record.")],
    poc_note="Listed. Never examined. Scores nothing."),

"butts-telford-moving-expenses": dict(
    operate=2, answer=3, show=2,
    oa_notes=dict(operate="Within the policy as written; $207,052 for two moves. They later called part of it 'unreasonable'.",
                  answer="Partial repayment ($65,000). He ordered a policy review.", show="The review's outcome is not on this record. No repeat."),
    poc=[T("T4", "E3", "office",
           "Public money ($207,052) went to his two most senior aides; the excess was admitted by the repayment of $65,000 as 'unreasonable'.",
           note="Within the policy; scored on the admitted excess only.")],
    poc_note=""),

"aga-khan-vacation": dict(
    operate=0, answer=2, show=0, repeat_of=["snc-lavalin-affair", "jamaica-vacation"], repeat_after_finding=True,
    oa_notes=dict(operate="Four sections of the Conflict of Interest Act broken by the prime minister personally.",
                  answer="Cooperated with the commissioner; said he accepted the report. No penalty exists; none was imposed; nothing repaid.",
                  show="Broke the same Act again within two years (SNC-Lavalin). A second free luxury vacation from a wealthy friend followed in 2023, pre-cleared this time."),
    poc=[T("T1", "E4", "him",
           "A gift (the island stay, the helicopter) from a party whose foundation was registered to lobby his office with a $15-million grant pending; not refused. Found by the commissioner."),
         T("T5", "E4", "him",
           "'The Aga Khan has been a long-time family friend' — the commissioner found no private interaction between the two men until Trudeau became Liberal leader, and that the relationship 'cannot be described as one of friends for the purposes of the Act'.")],
    poc_note=""),

# ── 2017 ──
"mark-norman-prosecution": dict(
    operate=1, answer=1, show=2, harm=True,
    oa_notes=dict(operate="The prime minister twice said publicly the matter would go to court before any charge existed. The charge was later stayed: 'no reasonable prospect of conviction'.",
                  answer="'Entirely independent of my office.' Left the chamber before the unanimous apology vote. No inquiry examined his statements.",
                  show="No repeat of a public pre-judgment of a prosecution in the record; nothing changed either."),
    poc=[T("T2", "E2", "him",
           "Publicly pre-judged (twice, on the record) a decision reserved to police and prosecutors. The statements are his; their effect was never examined by any body.",
           note="Counsel's claims that records were withheld and code names used were argued in court, not ruled on: not scored.")],
    poc_note=""),

"sajjan-operation-medusa": dict(
    operate=3, answer=2, show=None,
    oa_notes=dict(operate="A minister's false claim about his own record.", answer="Retracted and apologized; kept in the job.", show="Individual conduct; not applicable."),
    poc=[T("T5", "E3", "minister", "A public statement of fact ('the architect' of Operation Medusa), retracted by the minister himself, about his own service.")],
    poc_note=""),

"khadr-settlement": dict(
    operate=4, answer=4, show=None,
    oa_notes=dict(operate="A lawful settlement of Charter breaches the Supreme Court had found in 2008 and 2010.",
                  answer="Announced, apologized in writing, paid. The consequence landed on the treasury by the government's own decision.", show="Not applicable."),
    poc=[], poc_note="A settlement, not corruption."),

"julie-payette": dict(
    operate=2, answer=3, show=3, harm=True,
    oa_notes=dict(operate="Appointed without the vice-regal advisory committee created in 2012; vetting missed two matters on the public record.",
                  answer="His Privy Council Office commissioned the review; she resigned; he said vetting would be strengthened.",
                  show="An advisory group was used for the 2021 appointment. No repeat."),
    poc=[], poc_note="A skipped process and a bad appointment. Not corruption."),

"kang-harassment": dict(
    operate=3, answer=3, show=None, harm=True,
    oa_notes=dict(operate="An MP's personal conduct.", answer="House investigation; out of caucus for good.", show="Not applicable."),
    poc=[], poc_note="Personal conduct. Not corruption."),

"morneau-french-villa": dict(
    operate=1, answer=2, show=0, repeat_of=["morneau-we-charity"],
    oa_notes=dict(operate="A minister failed to declare a company for two years; the Act broken.",
                  answer="A $200 penalty; kept as finance minister.", show="The same minister broke the same Act three ways in 2020."),
    poc=[T("T7", "E4", "minister", "The disclosure rule of the Conflict of Interest Act, broken; found by the commissioner. No private benefit shown.")],
    poc_note=""),

# ── 2018 ──
"hehr-resignation": dict(
    operate=3, answer=2, show=None,
    oa_notes=dict(operate="A minister's personal conduct.", answer="He left cabinet. The PMO-commissioned report was never released.", show="Not applicable."),
    poc=[], poc_note="Personal conduct. The withheld report was sought by no investigator or committee: not obstruction under the elements."),

"india-trip-atwal": dict(
    operate=2, answer=1, show=2, against=True,
    oa_notes=dict(operate="Screening failures the security-cleared committee said the PMO 'should have more properly addressed'.",
                  answer="A background briefing blamed factions in India; the committee found no evidence the PMO ordered it. Nobody in the PMO was disciplined.",
                  show="No repeat in the record; nothing changed either."),
    poc=[], poc_note="A screening failure and a deflection. No element of any type met."),

"leblanc-surf-clam": dict(
    operate=1, answer=2, show=0, repeat_of=["ng-pomp-circumstance", "morneau-we-charity"],
    oa_notes=dict(operate="A minister awarded a licence to a company run by his wife's cousin; the Act broken.",
                  answer="The licence process was restarted. The minister was kept in cabinet through 2025. No penalty exists.",
                  show="Two more ministers failed to recuse and were found in breach: Ng (2022), Morneau (2021)."),
    poc=[T("T1", "E4", "minister", "A lucrative licence to a company run by a relative of the minister's wife; the company had business before the department; no recusal. Found by the commissioner.")],
    poc_note=""),

"vance-allegations-2018": dict(
    operate=1, answer=1, show=3, harm=True,
    oa_notes=dict(operate="Told of an allegation against the top general, the minister 'pushed back from the table and said, No' (the ombudsman, under oath). The general stayed three years and later pleaded guilty to obstruction of justice.",
                  answer="'Confidence in Sajjan' after the testimony; the minister was moved, not sanctioned; no official disciplined.",
                  show="Arbour's 48 recommendations accepted, including moving sexual-misconduct cases to civilian courts."),
    poc=[], poc_note="A refusal to look at evidence. No element of obstruction (no investigator sought records), no benefit, no false statement adjudicated: not corruption. Scored in OA."),

"trans-mountain": dict(
    operate=3, answer=3, show=None,
    oa_notes=dict(operate="A lawful purchase; the Parliamentary Budget Officer expects a loss on sale.", answer="Costs disclosed as they rose.", show="Open; not applicable."),
    poc=[], poc_note="A policy decision with a public bill. Not corruption."),

"kokanee-summit-allegation": dict(
    operate=None, answer=1, show=None,
    oa_notes=dict(operate="Conduct from 2000, before office.", answer="Denied acting inappropriately; 'the same interactions can be experienced very differently'. No body examined it.", show="Not applicable."),
    poc=[], poc_note="Personal conduct, pre-office, never examined. Not corruption under any type; listed in the record as never investigated."),

"grewal-charges": dict(
    operate=3, answer=3, show=None,
    oa_notes=dict(operate="An MP's personal conduct.", answer="Out of caucus; charged; acquitted.", show="Not applicable."),
    poc=[], poc_note="Acquitted. Not corruption."),

# ── 2019 ──
"snc-lavalin-affair": dict(
    operate=0, answer=0, show=0, repeat_of=["we-charity"], repeat_after_finding=True,
    oa_notes=dict(operate="Section 9 of the Conflict of Interest Act broken by the prime minister personally: improper influence on the attorney general.",
                  answer="Cabinet confidence was waived only in part; the commissioner and the RCMP both said it blocked their work, and Trudeau was never interviewed by the RCMP. Two ministers who would not go along were pushed out. 'I won't apologize.'",
                  show="Within a year he sat in on a $912-million decision involving an organization that had paid his family, and admitted he should have recused."),
    poc=[T("T2", "E4", "him",
           "The prime minister, his staff, the finance minister's office and the clerk pressed the attorney general over months to overrule the prosecution service on SNC-Lavalin — a decision reserved to her alone. Found by the commissioner."),
         T("T5", "E4", "him",
           "'The allegations in the Globe story this morning are false.' The commissioner found the pressure the story described had happened."),
         T("T6", "E4", "office",
           "The commissioner reported he was denied access to cabinet confidences for nine witnesses; the RCMP said cabinet secrecy blocked much of its investigation. The limits of the waiver were a cabinet decision.")],
    poc_note=""),

"liberalist-judicial-vetting": dict(
    operate=2, answer=1, show=None,
    oa_notes=dict(operate="Judicial candidates run through the party's voter database by the PMO; confirmed by the PMO; reported discontinued in 2021.",
                  answer="Defended as 'merit-based'. No body examined it.", show="Not applicable."),
    poc=[T("T4", "E1", "office", "If proven: appointments steered to party-connected candidates. The vetting is admitted; that appointments were skewed by it is not on this record.")],
    poc_note="Listed. The practice is admitted; the outcome element is not on the record, so it scores nothing."),

"ng-pomp-circumstance": dict(
    operate=1, answer=2, show=1, repeat_of=["hussen-constituency-contracts"],
    oa_notes=dict(operate="A minister gave contracts to a friend's firm; the Act broken by failing to recuse.",
                  answer="Apology. No penalty exists; no repayment; kept in cabinet.",
                  show="A month after the ruling, another minister's office was reported paying $93,000 to a staffer's relative's firm; never examined."),
    poc=[T("T1", "E4", "minister", "Contracts ($22,790) to a friend's firm; the firm had business with the office; no recusal. Found by the commissioner.")],
    poc_note=""),

"winnipeg-lab-documents": dict(
    operate=1, answer=0, show=0, against=True, repeat_of=["sdtc-green-fund"],
    oa_notes=dict(operate="'Lax adherence to the security protocols' — the health minister's own words, after two scientists with PRC ties were dismissed.",
                  answer="Twice ordered by the House to produce the records, the government refused, its agency head was admonished at the bar, and it sued the Speaker — the first such application ever. Released two and a half years later.",
                  show="In 2024 another House order for documents (the green fund) was not fully met."),
    poc=[T("T6", "E3", "office",
           "Parliament twice ordered the records; the government withheld them and filed a Federal Court application against the Speaker. The agency president was formally admonished by the House. All of it on the record, by the government's own acts.")],
    poc_note="The security lapse itself is scored in OA; the obstruction is the corrupt act."),

"blackface-images": dict(
    operate=None, answer=3, show=None,
    oa_notes=dict(operate="Conduct before office.", answer="Admitted, two apologies; could not say how many times.", show="Not applicable."),
    poc=[], poc_note="Personal conduct. Not corruption."),

# ── 2020 ──
"pandemic-preparedness-audit": dict(
    operate=1, answer=2, show=2,
    oa_notes=dict(operate="'Not adequately prepared': no early-warning alert, risk rated low until March 12, 2020, two-thirds of quarantines unverified.",
                  answer="Recommendations accepted. No consequence to any minister.", show="Closed as an audit matter; no corrective step on this record."),
    poc=[], poc_note="Unpreparedness. Not corruption."),

"baylis-ventilators": dict(
    operate=3, answer=2, show=None,
    oa_notes=dict(operate="Emergency procurement through an intermediary; a subcontractor co-owned by a former Liberal MP.",
                  answer="Defended in committee; the commissioner said the rules do not cover a former MP. Never examined.", show="Not applicable."),
    poc=[T("T4", "E1", "government", "If proven: a $237-million contract steered to a party-connected firm. The chain of contracts is documented; favouritism was never examined.")],
    poc_note="Listed. Scores nothing."),

"covid-benefit-overpayments": dict(
    operate=1, answer=1, show=1,
    oa_notes=dict(operate="Speed chosen over eligibility checks; $4.6 billion to the ineligible, $27.4 billion needing review.",
                  answer="The tax agency disputed the Auditor General's numbers and said checking was not worth it.",
                  show="Collection letters began in 2023; the agency's position that full verification is not worthwhile stands."),
    poc=[], poc_note="A design choice and its cost. Not corruption."),

"we-charity": dict(
    operate=2, answer=0, show=3, money_in_play=912_000_000,
    oa_notes=dict(operate="Sat in on the $912-million decision without recusing, with his mother and brother paid about $282,000 by the recipient. Cleared under the Act's definition of private interest; he apologized for not recusing.",
                  answer="Testified to the committee. Then prorogued Parliament, ending four committee studies, and made a motion for a special committee a confidence vote.",
                  show="The next free stay (Jamaica, 2023) was cleared in advance. No repeat of a non-recusal in the record."),
    poc=[T("T1", "E3", "him",
           "A benefit to his family (about $282,000 in fees from WE); WE had a $912-million programme before cabinet; he did not recuse — all admitted. Cleared because the Act's 'private interest' excludes relatives' fees.",
           note="Cleared under the Act, May 2021. The Supreme Court struck down the clause shielding that clearance in July 2026; the Federal Court of Appeal now reviews it.", cleared_under_law=True),
         T("T6", "E3", "him",
           "Four committee studies were under way; prorogation on August 18, 2020 ended them. A motion for a special committee was made a confidence vote and defeated. Both his decisions, on the record.")],
    poc_note=""),

"lucki-nova-scotia-call": dict(
    operate=3, answer=3, show=None,
    oa_notes=dict(operate="The inquiry found no attempted political interference; the commissioner's remarks were 'ill-timed and poorly expressed'.",
                  answer="Cooperated with the inquiry.", show="Not applicable."),
    poc=[], poc_note="Examined and no interference found. Not corruption."),

"arrivecan": dict(
    operate=1, answer=3, show=2,
    oa_notes=dict(operate="'Glaring disregard for basic management and contracting practices'; the true cost is unknowable.",
                  answer="Accepted the audit; two executives suspended without pay, the contractor banned and admonished by the House. No minister sanctioned.",
                  show="No corrective rule on this record; no repeat of the same procurement after the audit."),
    poc=[T("T4", "E4", "government",
           "Some $60 million of public money went to contractors without the controls the rules require; in 76% of contracts people paid for did no work (procurement ombud). Found by the Auditor General.")],
    poc_note=""),

"firearms-buyback-program": dict(
    operate=2, answer=3, show=None,
    oa_notes=dict(operate="$67.2 million spent over four years; no firearms collected — the government's own figures.",
                  answer="The figures were tabled in answer to Parliament.", show="Open; not applicable."),
    poc=[], poc_note="A programme that did not deliver. Not corruption."),

"morneau-we-charity": dict(
    operate=1, answer=3, show=None, money_in_play=912_000_000,
    oa_notes=dict(operate="A minister took free trips from WE, let his staff run interference for its funding, and sat in on the decision; the Act broken three ways.",
                  answer="He resigned as minister and MP.", show="He left office; not applicable."),
    poc=[T("T1", "E4", "minister", "Free travel from WE; WE had a $912-million programme before the minister; no recusal. Found by the commissioner: preferential treatment, a decision in conflict, failure to recuse.")],
    poc_note=""),

"nuctech-standing-offer": dict(
    operate=2, answer=3, show=2,
    oa_notes=dict(operate="Security experts were not part of the procurement (Deloitte).", answer="Reversed once reported.", show="No repeat in the record."),
    poc=[], poc_note="A procurement lapse, reversed. Not corruption."),

# ── 2021 ──
"access-to-information-decline": dict(
    operate=1, answer=1, show=1, against=True, repeat_of=["sdtc-green-fund"],
    oa_notes=dict(operate="The Information Commissioner: the system 'no longer serves its intended purpose'; transparency 'is not a priority for the government'.",
                  answer="The law was left unchanged.", show="A House order for documents was not fully met the following year."),
    poc=[], poc_note="Systemic non-transparency, scored in OA. No specific order or investigator refused in this case: not obstruction under the elements."),

"michael-chong-zhao-wei": dict(
    operate=1, answer=2, show=3, harm=True, against=True,
    oa_notes=dict(operate="Intelligence that an MP's family was being targeted 'did not flow as it should have'; the memo 'never reached the Minister'.",
                  answer="Said he had not been told; the diplomat was expelled after the story broke. No official disciplined.",
                  show="A foreign-interference law passed in 2024."),
    poc=[], poc_note="Negligence, not corruption."),

"blair-csis-warrant-delay": dict(
    operate=1, answer=2, show=2, against=True,
    oa_notes=dict(operate="A warrant sat in a minister's office 54 days: 'unacceptable', 'everyone involved dropped the ball'.",
                  answer="The minister said he signed when it reached him; the inquiry found no wrongdoing beyond diligence. He stayed.",
                  show="No repeat in the record; no process change on it."),
    poc=[], poc_note="Delay, not corruption."),

"afghanistan-evacuation-2021": dict(
    operate=1, answer=2, show=2, harm=True, against=True,
    oa_notes=dict(operate="Planning and coordination failures found by the special committee; an election called the day Kabul fell.",
                  answer="Two ministers shuffled; none resigned; the Liberal members dissented from parts of the report.",
                  show="No repeat; no corrective step on this record."),
    poc=[], poc_note="Operational failure. Not corruption."),

"snap-election-2021": dict(
    operate=3, answer=3, show=None,
    oa_notes=dict(operate="Lawful. A $574-million election two years early, in a pandemic, returning the same Parliament.",
                  answer="Answered for it publicly; no finding to answer.", show="Not applicable."),
    poc=[], poc_note="Calling an election is politics, whatever it costs. Not corruption."),

"sajjan-afghan-sikhs": dict(
    operate=None, answer=1, show=None,
    oa_notes=dict(operate="Never examined.", answer="Denied giving orders; stayed in cabinet.", show="Not applicable."),
    poc=[T("T4", "E1", "minister", "If proven: military resources directed for a domestic political constituency. Reported; denied; never examined.")],
    poc_note="Listed. Scores nothing."),

"tofino-truth-reconciliation-day": dict(
    operate=2, answer=3, show=2,
    oa_notes=dict(operate="The public itinerary said 'private meetings' in Ottawa; he was in Tofino.",
                  answer="Apologized by phone and in public; visited Tk'emlúps on October 18.", show="No repeat in the record."),
    poc=[T("T5", "E3", "office", "The itinerary his office issued stated a location that was false; corrected after a reporter asked. The office knew where he was.")],
    poc_note=""),

# ── 2022 ──
"emergencies-act-2022": dict(
    operate=0, answer=1, show=1, harm=True,
    oa_notes=dict(operate="'No national emergency justifying the invocation'; 'unreasonable and ultra vires'; account freezes breached the Charter. Two courts.",
                  answer="Appealed both rulings; 'that continues to be my belief today' (Freeland). No minister resigned. Cooperated with the Rouleau inquiry.",
                  show="Rouleau's recommendations accepted in principle; the Act unamended; the litigation continued to the Supreme Court."),
    poc=[T("T3", "E4", "him",
           "Bank accounts frozen (about 257) and protest powers used under a declaration the courts found had no lawful basis and breached the Charter. The declaration was cabinet's, announced by him.")],
    poc_note=""),

"mendicino-police-request-claim": dict(
    operate=2, answer=2, show=None,
    oa_notes=dict(operate="A minister told the public the police had asked for the Act; police chiefs testified no request was made.",
                  answer="Walked back by his deputy minister; the minister stayed a year.", show="Individual conduct; not applicable."),
    poc=[T("T5", "E3", "minister", "'Police asked for it' — contradicted by the police chiefs' testimony and walked back by his own deputy. The minister was in a position to know.")],
    poc_note=""),

"boissonnault-global-health-imports": dict(
    operate=3, answer=3, show=None,
    oa_notes=dict(operate="Texts about 'Randy'; the commissioner found no evidence he was running the company.", answer="Left cabinet 'to clear his name'.", show="Not applicable."),
    poc=[], poc_note="Examined; no element met at grade E2 or better."),

"london-hotel-queen-funeral": dict(
    operate=3, answer=1, show=None,
    oa_notes=dict(operate="Lawful spending; a $6,000-a-night suite on a $397,843 trip.", answer="The office would not say who stayed in the suite.", show="Not applicable."),
    poc=[], poc_note="Extravagance and a refusal to answer a reporter. Not corruption under the elements."),

"foreign-interference-response": dict(
    operate=1, answer=2, show=3, against=True,
    oa_notes=dict(operate="'Slow to act', 'insufficiently transparent' — the public inquiry.",
                  answer="Resisted a public inquiry (the rapporteur), then called one and gave it cabinet documents.", show="A foreign-interference law passed in 2024."),
    poc=[], poc_note="Slowness and poor communication. Not corruption."),

# ── 2023 ──
"mckinsey-outsourcing": dict(
    operate=1, answer=2, show=2,
    oa_notes=dict(operate="'Frequent disregard for procurement policies and guidance' across $209 million of contracts.",
                  answer="Ministers asked to review; nobody sanctioned.", show="No corrective rule on this record."),
    poc=[T("T4", "E4", "government", "$209 million in contracts awarded with frequent disregard for the procurement rules. Found by the Auditor General.")],
    poc_note="The Auditor General found no evidence of political direction in the awards; scored as money without the rules, at the department's proximity."),

"hussen-constituency-contracts": dict(
    operate=None, answer=1, show=None,
    oa_notes=dict(operate="Never examined.", answer="The office said the rules were followed. Nobody checked.", show="Not applicable."),
    poc=[T("T4", "E1", "minister", "If proven: $93,050 to a firm run by a staffer's sister. The payments are documented; impropriety was never examined.")],
    poc_note="Listed. Scores nothing."),

"han-dong": dict(
    operate=2, answer=3, show=3,
    oa_notes=dict(operate="Warned of nomination irregularities and kept the candidate; the inquiry left the irregularities undetermined.",
                  answer="Cooperated with the inquiry.", show="A foreign-interference law passed in 2024."),
    poc=[], poc_note="Undetermined by the inquiry. Not scored."),

"mendicino-bernardo-transfer": dict(
    operate=2, answer=2, show=None,
    oa_notes=dict(operate="Corrections' records show the minister's office was told months ahead; the minister said he learned from the news.",
                  answer="Blamed staff; dropped from cabinet four months later.", show="Not applicable."),
    poc=[T("T5", "E2", "minister", "'Found out from the news' — Corrections' records show his office was briefed months before. Whether the minister himself was told was never examined.")],
    poc_note=""),

"david-johnston-rapporteur": dict(
    operate=2, answer=2, show=2, against=True,
    oa_notes=dict(operate="A family friend and Trudeau Foundation member appointed to decide whether his government needed a public inquiry.",
                  answer="Defended the appointment against a 174–150 vote of the House; the rapporteur resigned; the inquiry followed.",
                  show="The inquiry he had resisted was called. No repeat."),
    poc=[T("T4", "E2", "him",
           "A $4.5-million appointment went to a long-time family friend; the House voted 174–150 that he step aside. The friendship is on the record; the vote is Parliament's, not an adjudication.")],
    poc_note=""),

"hunka-recognition": dict(
    operate=3, answer=3, show=None,
    oa_notes=dict(operate="The Speaker's invitation; the government said it was not consulted.", answer="Apologized on Parliament's behalf; the Speaker resigned.", show="Not applicable."),
    poc=[], poc_note="Not corruption."),

"sdtc-green-fund": dict(
    operate=1, answer=0, show=3,
    oa_notes=dict(operate="$59 million to ineligible projects; $76 million in 90 conflicted decisions; the department did not monitor.",
                  answer="A House order for unredacted documents was not fully met; the privilege debate consumed the House from September 26, 2024 to prorogation.",
                  show="The foundation was wound down. The order was never complied with."),
    poc=[T("T4", "E4", "government",
           "$76 million in 90 funding decisions where conflict-of-interest rules were not followed; $59 million to ineligible projects; the chair found in breach. Found by the Auditor General and the commissioner."),
         T("T6", "E3", "office",
           "The House ordered the documents; the government did not fully comply; the House sat on the privilege question for four months. On the record.")],
    poc_note=""),

"carbon-charge-heating-oil": dict(
    operate=3, answer=3, show=None,
    oa_notes=dict(operate="A lawful policy reversal; a minister said the Prairies should 'elect more Liberals' to get the same.", answer="On the record; the minister kept her job.", show="Not applicable."),
    poc=[], poc_note="Regional relief and a partisan remark. Relief to a region is not money to insiders: not scored."),

"jamaica-vacation": dict(
    operate=2, answer=2, show=None,
    oa_notes=dict(operate="A second free luxury stay from a wealthy friend, after the Aga Khan ruling; consulted the commissioner in advance.",
                  answer="The office gave three descriptions of who paid before the commissioner's account settled it.", show="Not applicable."),
    poc=[T("T5", "E3", "office", "'The family was covering the cost' — then 'at no cost at a location owned by family friends' — then 'with family friends'. The office's own three statements, on the record.")],
    poc_note="The stay itself was cleared in advance and the host had no dealings with the government: not self-dealing under the elements."),

# ── 2024 ──
"nsicop-2024-parliamentarians": dict(
    operate=3, answer=3, show=None,
    oa_notes=dict(operate="A committee's claim the inquiry later found 'more definitive than the underlying intelligence could support'.", answer="Cooperated with the inquiry.", show="Not applicable."),
    poc=[], poc_note="Not corruption."),

"immigration-could-have-acted-quicker": dict(
    operate=2, answer=3, show=None,
    oa_notes=dict(operate="Admitted the government 'could have acted quicker'.", answer="Admitted on video; targets cut.", show="End of tenure; not applicable."),
    poc=[], poc_note="An admitted policy error. Not corruption."),

"freeland-resignation": dict(
    operate=2, answer=3, show=None,
    oa_notes=dict(operate="The finance minister's own ceiling ($40.1 billion) breached by $21.8 billion; 'costly political gimmicks' in her letter.",
                  answer="She left; the update was tabled; he announced his own resignation three weeks later.", show="End of tenure; not applicable."),
    poc=[], poc_note="A resignation and a missed target. Not corruption."),

# ── 2025 ──
"prorogation-2025": dict(
    operate=4, answer=4, show=None,
    oa_notes=dict(operate="Within his power; the court examined the purpose and upheld it.", answer="Defended in court; upheld.", show="Not applicable."),
    poc=[], poc_note="Examined by a court and upheld. The green-fund order it ended is scored in that case."),

"trudeau-resignation": dict(
    operate=3, answer=4, show=None,
    oa_notes=dict(operate="Resigned under pressure from his own caucus.", answer="The consequence at the top: he left office.", show="Not applicable."),
    poc=[], poc_note="Not corruption."),
}
